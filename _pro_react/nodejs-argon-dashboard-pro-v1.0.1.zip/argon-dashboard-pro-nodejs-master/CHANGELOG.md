# Change Log

## [1.0.1] 2019-06-05
### Added
 - Fixed sales value issue that occured when toggling between Month and Week

## [1.0.0] 2019-03-04
### Initial Release